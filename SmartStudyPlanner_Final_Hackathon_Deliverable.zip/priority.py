def calculate_priority(subject):
    """
    Smart priority score out of 100.

    Factors:
    - Exam urgency: 40 points
    - Difficulty: 25 points
    - Current progress: 20 points
    - Test performance: 15 points
    """

    days = max(int(subject.get("days_remaining", 0)), 0)
    difficulty = str(subject.get("difficulty", "Medium")).lower()
    progress = int(subject.get("progress", 0))
    test_score = int(subject.get("test_score", 0))

    if days <= 3:
        urgency_score = 40
    elif days <= 7:
        urgency_score = 30
    elif days <= 14:
        urgency_score = 20
    else:
        urgency_score = 10

    if difficulty in {"hard", "high"}:
        difficulty_score = 25
    elif difficulty in {"medium"}:
        difficulty_score = 15
    else:
        difficulty_score = 5

    if progress <= 25:
        progress_score = 20
    elif progress <= 50:
        progress_score = 15
    elif progress <= 75:
        progress_score = 10
    else:
        progress_score = 5

    if test_score <= 40:
        test_score_points = 15
    elif test_score <= 60:
        test_score_points = 10
    elif test_score <= 80:
        test_score_points = 5
    else:
        test_score_points = 0

    total_score = (
        urgency_score
        + difficulty_score
        + progress_score
        + test_score_points
    )

    if total_score >= 80:
        priority = "HIGH"
        emoji = "🔴"
        study_time = 120
    elif total_score >= 50:
        priority = "MEDIUM"
        emoji = "🟡"
        study_time = 60
    else:
        priority = "LOW"
        emoji = "🟢"
        study_time = 30

    return {
        **subject,
        "urgency_score": urgency_score,
        "difficulty_score": difficulty_score,
        "progress_score": progress_score,
        "test_score_points": test_score_points,
        "priority_score": total_score,
        "priority": priority,
        "emoji": emoji,
        "recommended_minutes": study_time,
    }


def calculate_all_priorities(subjects):
    results = [calculate_priority(subject) for subject in subjects]
    results.sort(
        key=lambda item: item["priority_score"],
        reverse=True,
    )
    return results


def get_top_subject(results):
    return results[0] if results else None
