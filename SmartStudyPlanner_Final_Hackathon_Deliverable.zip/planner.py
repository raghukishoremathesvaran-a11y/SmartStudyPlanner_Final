from datetime import date, datetime, timedelta


DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def days_until(exam_date, from_date=None):
    current = from_date or date.today()
    exam = date.fromisoformat(exam_date) if isinstance(exam_date, str) else exam_date
    return max((exam - current).days, 1)


def score_subject(subject, from_date=None):
    days = days_until(subject["exam_date"], from_date)
    urgency = 1 / days

    difficulty_map = {
        "Easy": 1,
        "Medium": 2,
        "Hard": 3,
    }

    difficulty = difficulty_map.get(subject["difficulty"], 1) / 3
    weak = (100 - float(subject.get("progress", 0))) / 100

    return urgency * 0.5 + difficulty * 0.3 + weak * 0.2


def pick_topic(subject):
    progress = float(subject.get("progress", 0))

    if progress < 40:
        return "Fundamentals + weak areas"
    if progress < 75:
        return "Practice problems"
    return "Revision + mock test"


def format_time(minutes_from_midnight):
    minutes_from_midnight = int(minutes_from_midnight)
    hour = (minutes_from_midnight // 60) % 24
    minute = minutes_from_midnight % 60
    suffix = "AM" if hour < 12 else "PM"
    display_hour = hour % 12 or 12
    return f"{display_hour}:{minute:02d} {suffix}"


def hours_map_from_availability(availability):
    selected = set(availability.get("days", []))
    daily_hours = float(availability.get("daily_hours", 3))

    mapping = {}
    for day in DAY_NAMES:
        mapping[day] = daily_hours if day in selected else 0

    return mapping


def generate_plan(
    subjects,
    hours_per_day,
    start_date=None,
    days_ahead=7,
    start_time="18:00",
):
    if not subjects:
        return []

    start = start_date or date.today()

    try:
        start_hour, start_minute = map(int, start_time.split(":"))
    except ValueError:
        start_hour, start_minute = 18, 0

    start_minutes = start_hour * 60 + start_minute
    plan = []

    for offset in range(days_ahead):
        current = start + timedelta(days=offset)
        day_name = current.strftime("%a")
        available = float(hours_per_day.get(day_name, 0))

        if available <= 0:
            plan.append({
                "date": current.isoformat(),
                "day": current.strftime("%A"),
                "sessions": [],
            })
            continue

        live = [
            subject
            for subject in subjects
            if date.fromisoformat(subject["exam_date"]) >= current
        ]

        ranked = sorted(
            live,
            key=lambda item: score_subject(item, current),
            reverse=True,
        )

        if not ranked:
            plan.append({
                "date": current.isoformat(),
                "day": current.strftime("%A"),
                "sessions": [],
            })
            continue

        total_score = sum(
            score_subject(subject, current)
            for subject in ranked
        )

        sessions = []
        remaining_minutes = round(available * 60)
        clock = start_minutes

        for subject in ranked:
            if remaining_minutes < 30:
                break

            share_hours = (
                score_subject(subject, current) / total_score
            ) * available

            share_hours = round(share_hours * 2) / 2
            share_hours = min(2.5, max(0.5, share_hours))

            session_minutes = min(
                int(share_hours * 60),
                remaining_minutes,
            )

            if session_minutes < 30:
                continue

            end_clock = clock + session_minutes

            sessions.append({
                "subject": subject["subject"],
                "subject_id": subject["id"],
                "start": format_time(clock),
                "end": format_time(end_clock),
                "hours": round(session_minutes / 60, 1),
                "topic": pick_topic(subject),
            })

            clock = end_clock + 15
            remaining_minutes -= session_minutes + 15

        plan.append({
            "date": current.isoformat(),
            "day": current.strftime("%A"),
            "sessions": sessions,
        })

    return plan


def find_slot(subject, missed_date, hours_per_day, days_ahead=7):
    start = (
        date.fromisoformat(missed_date)
        if isinstance(missed_date, str)
        else missed_date
    )

    for offset in range(1, days_ahead + 1):
        candidate = start + timedelta(days=offset)

        if date.fromisoformat(subject["exam_date"]) <= candidate:
            return None

        day_name = candidate.strftime("%a")

        if hours_per_day.get(day_name, 0) > 0:
            return {
                "subject": subject["subject"],
                "subject_id": subject["id"],
                "date": candidate.isoformat(),
                "hours": 1,
                "topic": pick_topic(subject),
                "rescheduled": True,
            }

    return None
