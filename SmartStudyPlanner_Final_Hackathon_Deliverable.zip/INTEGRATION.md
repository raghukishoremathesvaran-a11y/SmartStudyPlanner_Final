# Final Integration Map

Member 1 — UI
- Responsive SmartStudy interface
- Navigation, dashboard, profile, subject form, availability form

Member 2 — Study Planner
- Priority-aware seven-day schedule generation
- Availability-aware session allocation
- Topic selection based on progress

Member 3 — Smart Logic + AI
- Priority score: urgency + difficulty + progress + test performance
- Personalized recommendations
- Gemini AI assistant for free-text study questions

Member 4 — Data + Progress
- SQLite database
- Persistent profile and subject records
- Study-session tracking
- Progress updates from completed sessions

Architecture:
Browser → Flask API → SQLite / Smart Logic / Planner / Gemini → Browser
