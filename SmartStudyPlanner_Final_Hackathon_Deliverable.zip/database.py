import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "study_planner.db"


def get_connection():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with get_connection() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT,
                course TEXT
            );

            CREATE TABLE IF NOT EXISTS subjects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                subject_name TEXT NOT NULL,
                exam_date TEXT NOT NULL,
                difficulty TEXT NOT NULL,
                progress INTEGER DEFAULT 0,
                test_score INTEGER DEFAULT 0,
                study_hours REAL DEFAULT 1,
                completed_hours REAL DEFAULT 0,
                FOREIGN KEY (student_id) REFERENCES students(id)
            );

            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                subject_id INTEGER NOT NULL,
                task_name TEXT NOT NULL,
                task_date TEXT NOT NULL,
                status TEXT DEFAULT 'Pending',
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (subject_id) REFERENCES subjects(id)
            );

            CREATE TABLE IF NOT EXISTS study_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject_id INTEGER NOT NULL,
                session_date TEXT NOT NULL,
                duration REAL NOT NULL,
                FOREIGN KEY (subject_id) REFERENCES subjects(id)
            );

            CREATE TABLE IF NOT EXISTS availability (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                days TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                daily_hours REAL NOT NULL
            );
            """
        )

        student = conn.execute(
            "SELECT id FROM students ORDER BY id LIMIT 1"
        ).fetchone()

        if student is None:
            conn.execute(
                "INSERT INTO students (name, email, course) VALUES (?, ?, ?)",
                ("", "", ""),
            )

        availability = conn.execute(
            "SELECT id FROM availability WHERE id = 1"
        ).fetchone()

        if availability is None:
            conn.execute(
                """
                INSERT INTO availability
                (id, days, start_time, end_time, daily_hours)
                VALUES (1, ?, ?, ?, ?)
                """,
                ("Monday,Tuesday,Wednesday,Thursday,Friday", "18:00", "21:00", 3),
            )

        conn.commit()


def student_id():
    with get_connection() as conn:
        row = conn.execute(
            "SELECT id FROM students ORDER BY id LIMIT 1"
        ).fetchone()
        return row["id"]


def save_profile(name, email, course):
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE students
            SET name = ?, email = ?, course = ?
            WHERE id = ?
            """,
            (name, email, course, student_id()),
        )
        conn.commit()


def get_subjects():
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT
                s.id,
                s.subject_name,
                s.exam_date,
                s.difficulty,
                s.progress,
                s.test_score,
                s.study_hours,
                COALESCE(s.completed_hours, 0) AS completed_hours
            FROM subjects s
            WHERE s.student_id = ?
            ORDER BY s.exam_date ASC
            """,
            (student_id(),),
        ).fetchall()

    return [dict(row) for row in rows]


def add_subject(
    name,
    exam_date,
    difficulty,
    progress,
    test_score,
    study_hours,
):
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO subjects
            (student_id, subject_name, exam_date, difficulty,
             progress, test_score, study_hours, completed_hours)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0)
            """,
            (
                student_id(),
                name,
                exam_date,
                difficulty,
                progress,
                test_score,
                study_hours,
            ),
        )
        conn.commit()
        return cursor.lastrowid


def delete_subject(subject_id):
    with get_connection() as conn:
        conn.execute(
            "DELETE FROM study_sessions WHERE subject_id = ?",
            (subject_id,),
        )
        conn.execute(
            "DELETE FROM tasks WHERE subject_id = ?",
            (subject_id,),
        )
        conn.execute(
            "DELETE FROM subjects WHERE id = ? AND student_id = ?",
            (subject_id, student_id()),
        )
        conn.commit()


def add_study_session(subject_id, session_date, duration):
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO study_sessions
            (subject_id, session_date, duration)
            VALUES (?, ?, ?)
            """,
            (subject_id, session_date, duration),
        )

        conn.execute(
            """
            UPDATE subjects
            SET completed_hours = completed_hours + ?,
                progress = MIN(
                    100,
                    CAST(
                        ((completed_hours + ?) / study_hours) * 100
                        AS INTEGER
                    )
                )
            WHERE id = ?
            """,
            (duration, duration, subject_id),
        )

        conn.commit()


def save_availability(days, start_time, end_time, daily_hours):
    with get_connection() as conn:
        conn.execute(
            """
            INSERT OR REPLACE INTO availability
            (id, days, start_time, end_time, daily_hours)
            VALUES (1, ?, ?, ?, ?)
            """,
            (",".join(days), start_time, end_time, daily_hours),
        )
        conn.commit()


def get_availability():
    with get_connection() as conn:
        row = conn.execute(
            "SELECT days, start_time, end_time, daily_hours FROM availability WHERE id = 1"
        ).fetchone()

    if not row:
        return {
            "days": [],
            "start_time": "18:00",
            "end_time": "21:00",
            "daily_hours": 3,
        }

    return {
        "days": row["days"].split(",") if row["days"] else [],
        "start_time": row["start_time"],
        "end_time": row["end_time"],
        "daily_hours": row["daily_hours"],
    }


def get_dashboard_data():
    with get_connection() as conn:
        profile_row = conn.execute(
            "SELECT name, email, course FROM students WHERE id = ?",
            (student_id(),),
        ).fetchone()

        sessions = conn.execute(
            """
            SELECT
                ss.session_date,
                ss.duration,
                s.subject_name
            FROM study_sessions ss
            JOIN subjects s ON s.id = ss.subject_id
            ORDER BY ss.id DESC
            LIMIT 8
            """
        ).fetchall()

        tasks = conn.execute(
            """
            SELECT
                t.id,
                t.task_name,
                t.task_date,
                t.status,
                s.subject_name
            FROM tasks t
            JOIN subjects s ON s.id = t.subject_id
            WHERE t.student_id = ?
            ORDER BY t.task_date
            LIMIT 20
            """,
            (student_id(),),
        ).fetchall()

    return {
        "profile": dict(profile_row) if profile_row else {},
        "recent_sessions": [dict(row) for row in sessions],
        "tasks": [dict(row) for row in tasks],
        "availability": get_availability(),
    }
