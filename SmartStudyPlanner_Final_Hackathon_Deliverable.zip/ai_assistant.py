import os

from dotenv import load_dotenv

try:
    from google import genai
except ImportError:
    genai = None

load_dotenv()


def create_recommendation(subject):
    name = subject["subject"]
    priority = subject["priority"]
    days = subject["days_remaining"]
    progress = subject["progress"]
    test_score = subject["test_score"]
    minutes = subject["recommended_minutes"]

    if priority == "HIGH":
        return (
            f"⚠️ {name} needs more attention.\n\n"
            f"You have {days} day(s) remaining, your progress is "
            f"{progress}%, and your latest test score is {test_score}%.\n\n"
            f"Recommended focused study time: {minutes} minutes/day."
        )

    if priority == "MEDIUM":
        return (
            f"📚 {name} should receive regular attention.\n\n"
            f"You have {days} day(s) remaining and your progress is "
            f"{progress}%.\n\n"
            f"Recommended study time: {minutes} minutes/day."
        )

    return (
        f"✅ {name} is currently under control.\n\n"
        f"Your progress is {progress}% and you have {days} day(s) remaining.\n\n"
        f"Recommended maintenance time: {minutes} minutes/day."
    )


def build_study_context(subjects):
    if not subjects:
        return "No subjects have been added yet."

    lines = ["Student's current study information:"]
    for subject in subjects:
        lines.append(
            f"- {subject['subject']}: "
            f"{subject['days_remaining']} days remaining, "
            f"difficulty {subject['difficulty']}, "
            f"progress {subject['progress']}%, "
            f"test score {subject['test_score']}%, "
            f"priority {subject['priority']} "
            f"(score {subject['priority_score']})."
        )
    return "\n".join(lines)


def ask_gemini(question, subjects):
    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        return (
            "⚠️ Gemini API key is not configured. "
            "Add GEMINI_API_KEY to your private .env file."
        )

    if genai is None:
        return (
            "⚠️ The Google GenAI package is not installed. "
            "Run: pip install -r requirements.txt"
        )

    context = build_study_context(subjects)

    prompt = f"""
You are the AI Study Assistant inside Smart Study Planner.

You can answer any study-related question from a college student,
including Java, Python, C, C++, DBMS, SQL, data structures,
algorithms, operating systems, computer networks, mathematics,
exam preparation, coding doubts, study planning and concept
explanations.

Student context:
{context}

Student question:
{question}

Instructions:
- Answer the actual question directly.
- Be clear and beginner-friendly.
- Use the student's study context when it is relevant.
- If asked what to study today, recommend the highest-priority subject.
- If asked for code, provide complete code and explain it briefly.
- Do not claim facts about the student that are not in the context.
"""

    try:
        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model="gemini-3.8-flash",
            contents=prompt,
        )

        if response.text:
            return response.text

        return "⚠️ Gemini returned an empty response."

    except Exception as error:
        print("Gemini error:", error)
        return (
            "⚠️ I couldn't connect to Gemini right now.\n\n"
            f"Error: {error}"
        )
