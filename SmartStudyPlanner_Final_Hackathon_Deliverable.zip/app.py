import os
from datetime import date, datetime, timedelta

from flask import Flask, jsonify, render_template, request

from ai_assistant import ask_gemini, create_recommendation
from database import (
    add_subject,
    add_study_session,
    delete_subject,
    get_dashboard_data,
    get_subjects,
    init_db,
    save_availability,
    save_profile,
)
from planner import generate_plan, hours_map_from_availability
from priority import calculate_all_priorities

app = Flask(__name__)
init_db()


def enrich_subjects():
    """Load database subjects and add smart-priority fields."""
    rows = get_subjects()
    enriched = []

    for subject in rows:
        exam = date.fromisoformat(subject["exam_date"])
        days_remaining = max((exam - date.today()).days, 0)

        item = {
            "id": subject["id"],
            "subject": subject["subject_name"],
            "days_remaining": days_remaining,
            "difficulty": subject["difficulty"],
            "progress": subject["progress"],
            "test_score": subject["test_score"],
            "study_hours": subject["study_hours"],
            "completed_hours": subject["completed_hours"],
            "exam_date": subject["exam_date"],
        }
        enriched.append(item)

    return calculate_all_priorities(enriched)


@app.route("/")
def home():
    return render_template("index.html")


@app.get("/api/dashboard")
def dashboard():
    subjects = enrich_subjects()
    data = get_dashboard_data()

    recommendations = [
        {
            "subject": item["subject"],
            "priority": item["priority"],
            "message": create_recommendation(item),
        }
        for item in subjects
    ]

    total_study_hours = round(
        sum(item["study_hours"] for item in subjects), 1
    )
    completed_hours = round(
        sum(item["completed_hours"] for item in subjects), 1
    )

    average_progress = (
        round(sum(item["progress"] for item in subjects) / len(subjects))
        if subjects
        else 0
    )

    top_subject = subjects[0] if subjects else None

    upcoming = None
    dated = [
        item for item in subjects
        if item["days_remaining"] >= 0
    ]
    if dated:
        upcoming = min(dated, key=lambda x: x["days_remaining"])

    return jsonify({
        "profile": data["profile"],
        "subjects": subjects,
        "recommendations": recommendations,
        "total_subjects": len(subjects),
        "average_progress": average_progress,
        "total_study_hours": total_study_hours,
        "completed_hours": completed_hours,
        "highest_priority": top_subject["subject"] if top_subject else "None",
        "upcoming_exam": upcoming,
        "recent_sessions": data["recent_sessions"],
        "tasks": data["tasks"],
        "availability": data["availability"],
    })


@app.post("/api/profile")
def profile():
    payload = request.get_json() or {}
    name = payload.get("name", "").strip()
    email = payload.get("email", "").strip()
    course = payload.get("course", "").strip()

    if not name or not email or not course:
        return jsonify({"success": False, "message": "Please fill in all profile fields."}), 400

    save_profile(name, email, course)
    return jsonify({"success": True, "message": "Profile saved successfully."})


@app.post("/api/subjects")
def create_subject():
    payload = request.get_json() or {}

    try:
        name = payload["name"].strip()
        exam_date = payload["exam_date"]
        difficulty = payload.get("difficulty", "Medium")
        progress = int(payload.get("progress", 0))
        test_score = int(payload.get("test_score", 0))
        study_hours = float(payload.get("study_hours", 1))

        if not name:
            raise ValueError("Subject name is required.")
        if difficulty not in {"Easy", "Medium", "Hard"}:
            raise ValueError("Difficulty must be Easy, Medium or Hard.")
        if not 0 <= progress <= 100:
            raise ValueError("Progress must be between 0 and 100.")
        if not 0 <= test_score <= 100:
            raise ValueError("Test score must be between 0 and 100.")
        if study_hours <= 0:
            raise ValueError("Study hours must be greater than 0.")

        date.fromisoformat(exam_date)

        subject_id = add_subject(
            name,
            exam_date,
            difficulty,
            progress,
            test_score,
            study_hours,
        )

        return jsonify({
            "success": True,
            "message": f"{name} added successfully.",
            "id": subject_id,
        })

    except (KeyError, ValueError) as error:
        return jsonify({"success": False, "message": str(error)}), 400


@app.delete("/api/subjects/<int:subject_id>")
def remove_subject(subject_id):
    delete_subject(subject_id)
    return jsonify({"success": True, "message": "Subject deleted."})


@app.post("/api/availability")
def availability():
    payload = request.get_json() or {}

    try:
        days = payload.get("days", [])
        start_time = payload.get("start_time", "18:00")
        end_time = payload.get("end_time", "21:00")
        daily_hours = float(payload.get("daily_hours", 3))

        if not days:
            raise ValueError("Select at least one study day.")
        if daily_hours <= 0:
            raise ValueError("Daily study hours must be greater than 0.")

        save_availability(days, start_time, end_time, daily_hours)

        return jsonify({
            "success": True,
            "message": "Availability saved successfully.",
        })

    except ValueError as error:
        return jsonify({"success": False, "message": str(error)}), 400


@app.get("/api/plan")
def study_plan():
    subjects = enrich_subjects()
    data = get_dashboard_data()
    availability_data = data["availability"]

    hours_per_day = hours_map_from_availability(availability_data)

    plan = generate_plan(
        subjects,
        hours_per_day,
        start_date=date.today(),
        days_ahead=7,
        start_time=availability_data.get("start_time", "18:00"),
    )

    return jsonify({
        "plan": plan,
        "availability": availability_data,
    })


@app.post("/api/sessions")
def session():
    payload = request.get_json() or {}

    try:
        subject_id = int(payload["subject_id"])
        duration = float(payload["duration"])
        session_date = payload.get("date", date.today().isoformat())

        if duration <= 0:
            raise ValueError("Duration must be greater than zero.")

        add_study_session(subject_id, session_date, duration)

        return jsonify({
            "success": True,
            "message": "Study session recorded.",
        })

    except (KeyError, ValueError) as error:
        return jsonify({"success": False, "message": str(error)}), 400


@app.post("/api/ask")
def ask():
    payload = request.get_json() or {}
    question = payload.get("question", "").strip()

    if not question:
        return jsonify({"answer": "Please enter a question."}), 400

    subjects = enrich_subjects()
    answer = ask_gemini(question, subjects)

    return jsonify({"answer": answer})


@app.get("/api/priorities")
def priorities():
    return jsonify(enrich_subjects())


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "application": "Smart Study Planner"})


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
