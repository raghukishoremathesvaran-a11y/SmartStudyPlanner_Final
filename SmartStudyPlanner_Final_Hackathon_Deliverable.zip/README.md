# SmartStudy — Smart Study Planner

Final integrated hackathon deliverable combining the four team modules:

1. **User Interface** — responsive dashboard, profile, subject management and navigation.
2. **Study Planner** — seven-day timetable generation based on availability and subject priority.
3. **Smart Logic + AI** — priority scoring, personalized recommendations and Gemini AI assistant.
4. **Data + Progress** — SQLite persistence, study-session tracking and progress updates.

## Technology

- Python
- Flask
- SQLite
- HTML / CSS / JavaScript
- Google Gemini API

## Project structure

```text
SmartStudyPlanner_Final/
├── app.py
├── database.py
├── planner.py
├── priority.py
├── ai_assistant.py
├── requirements.txt
├── .gitignore
├── .env.example
├── README.md
├── study_planner.db       # created automatically on first run
├── templates/
│   └── index.html
└── static/
    ├── script.js
    └── style.css
```

## Run locally

### 1. Open PowerShell in this folder

```powershell
cd path\to\SmartStudyPlanner_Final
```

### 2. Install dependencies

```powershell
pip install -r requirements.txt
```

### 3. Create a private `.env`

Copy `.env.example` to `.env` and put your Gemini API key in it:

```text
GEMINI_API_KEY=YOUR_PRIVATE_KEY
```

Never upload `.env` to GitHub or send it to teammates.

### 4. Start the application

```powershell
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## Main demo flow

1. Save student profile.
2. Add subjects with exam date, difficulty, progress, test score and required study hours.
3. Show the smart priority score and breakdown.
4. Set study availability.
5. Generate the seven-day study plan.
6. Mark study sessions as completed.
7. Show progress updates.
8. Ask the AI Assistant any study-related question.

## Smart priority formula

The priority score is out of 100:

- Exam urgency: 40 points
- Subject difficulty: 25 points
- Current progress: 20 points
- Test performance: 15 points

Priority levels:

- 80–100 → HIGH
- 50–79 → MEDIUM
- 0–49 → LOW

## Security

The Gemini API key belongs only in `.env`. `.env` is excluded by `.gitignore`.

## Integration note

The original team submissions used different architectures. The final deliverable standardizes the application on **Flask + SQLite** so all four modules run as one application instead of four separate programs.
