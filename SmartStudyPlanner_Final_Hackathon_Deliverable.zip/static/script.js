let dashboardData = null;

document.addEventListener("DOMContentLoaded", () => {
    loadDashboard();
    loadPlan();
    setupForms();
    setupTheme();
});

function setupForms() {
    document.getElementById("profileForm").addEventListener("submit", saveProfile);
    document.getElementById("subjectForm").addEventListener("submit", addSubject);
    document.getElementById("availabilityForm").addEventListener("submit", saveAvailability);
}

async function api(url, options = {}) {
    const response = await fetch(url, {
        headers: {"Content-Type": "application/json"},
        ...options
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || data.answer || "Request failed.");
    }

    return data;
}

async function loadDashboard() {
    try {
        dashboardData = await api("/api/dashboard");
        renderProfile(dashboardData.profile);
        renderDashboard(dashboardData);
        renderSubjects(dashboardData.subjects);
        renderRecommendations(dashboardData.recommendations);
        renderSessions(dashboardData.recent_sessions);
        renderTasks(dashboardData.subjects);
        restoreAvailability(dashboardData.availability);
    } catch (error) {
        showToast(error.message, "error");
    }
}

function renderProfile(profile) {
    document.getElementById("studentName").value = profile?.name || "";
    document.getElementById("studentEmail").value = profile?.email || "";
    document.getElementById("course").value = profile?.course || "";
}

function renderDashboard(data) {
    document.getElementById("totalSubjects").textContent = data.total_subjects;
    document.getElementById("averageProgress").textContent = `${data.average_progress}%`;
    document.getElementById("studyHours").textContent = `${data.total_study_hours} h`;
    document.getElementById("completedHours").textContent = `${data.completed_hours} h`;
    document.getElementById("highestPriority").textContent = data.highest_priority;

    const upcoming = data.upcoming_exam;
    document.getElementById("upcomingExam").textContent = upcoming
        ? `${upcoming.subject} (${upcoming.days_remaining}d)`
        : "None";
}

function renderSubjects(subjects) {
    const container = document.getElementById("subjectCards");

    if (!subjects.length) {
        container.innerHTML = `
            <div class="empty-state">
                <h3>No subjects added yet</h3>
                <p>Add your first subject above.</p>
            </div>`;
        return;
    }

    container.innerHTML = subjects.map(subject => {
        const priorityClass = subject.priority.toLowerCase();
        const progress = Math.min(100, Math.max(0, Number(subject.progress)));

        return `
            <article class="subject-card priority-${priorityClass}">
                <div class="subject-card-header">
                    <div>
                        <h3>${escapeHTML(subject.subject)}</h3>
                        <span class="priority-badge">${subject.emoji} ${subject.priority}</span>
                    </div>
                    <strong class="priority-score">${subject.priority_score}/100</strong>
                </div>

                <p><strong>📅 Exam:</strong> ${formatDate(subject.exam_date)} — ${subject.days_remaining} day(s)</p>
                <p><strong>🔥 Difficulty:</strong> ${escapeHTML(subject.difficulty)}</p>
                <p><strong>📝 Test:</strong> ${subject.test_score}%</p>

                <div class="progress-label">
                    <span>Progress</span><strong>${progress}%</strong>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width:${progress}%"></div>
                </div>

                <div class="subject-stats">
                    <div><span>Study Needed</span><strong>${subject.study_hours} h</strong></div>
                    <div><span>Completed</span><strong>${subject.completed_hours} h</strong></div>
                    <div><span>Recommended</span><strong>${subject.recommended_minutes} min/day</strong></div>
                    <div><span>Priority Score</span><strong>${subject.priority_score}/100</strong></div>
                </div>

                <div class="breakdown">
                    <h4>Priority Breakdown</h4>
                    <div><span>Exam urgency</span><strong>${subject.urgency_score}/40</strong></div>
                    <div><span>Difficulty</span><strong>${subject.difficulty_score}/25</strong></div>
                    <div><span>Progress gap</span><strong>${subject.progress_score}/20</strong></div>
                    <div><span>Test performance</span><strong>${subject.test_score_points}/15</strong></div>
                </div>

                <button class="delete-button" onclick="deleteSubject(${subject.id})">Delete Subject</button>
            </article>`;
    }).join("");
}

function renderRecommendations(recommendations) {
    const container = document.getElementById("recommendationCards");

    if (!recommendations.length) {
        container.innerHTML = `<div class="empty-state"><p>Add subjects to receive personalized recommendations.</p></div>`;
        return;
    }

    container.innerHTML = recommendations.map(item => `
        <article class="recommendation-card ${item.priority.toLowerCase()}">
            <h3>${escapeHTML(item.subject)} — ${item.priority}</h3>
            <p>${formatText(item.message)}</p>
        </article>
    `).join("");
}

function renderSessions(sessions) {
    const container = document.getElementById("recentSessions");

    if (!sessions.length) {
        container.innerHTML = "<p>No study sessions yet.</p>";
        return;
    }

    container.innerHTML = sessions.map(session => `
        <div class="recent-session">
            <strong>${escapeHTML(session.subject_name)}</strong>
            <span>${session.duration} hour(s) · ${formatDate(session.session_date)}</span>
        </div>
    `).join("");
}

function renderTasks(subjects) {
    const container = document.getElementById("taskProgress");

    if (!subjects.length) {
        container.innerHTML = `<div class="empty-state"><p>Progress tracking will appear after you add subjects.</p></div>`;
        return;
    }

    container.innerHTML = subjects.map(subject => {
        const remaining = Math.max(0, subject.study_hours - subject.completed_hours);
        return `
            <div class="task-card">
                <div>
                    <h3>${escapeHTML(subject.subject)}</h3>
                    <p>${subject.completed_hours} / ${subject.study_hours} hours completed</p>
                </div>
                <button onclick="recordSession(${subject.id}, '${escapeJS(subject.subject)}', ${Math.min(1, remaining)})"
                    ${remaining <= 0 ? "disabled" : ""}>
                    ${remaining <= 0 ? "Completed ✓" : `Log ${Math.min(1, remaining)}h`}
                </button>
            </div>`;
    }).join("");
}

async function saveProfile(event) {
    event.preventDefault();

    try {
        const data = await api("/api/profile", {
            method: "POST",
            body: JSON.stringify({
                name: document.getElementById("studentName").value.trim(),
                email: document.getElementById("studentEmail").value.trim(),
                course: document.getElementById("course").value.trim()
            })
        });

        showToast(data.message);
        loadDashboard();
    } catch (error) {
        showToast(error.message, "error");
    }
}

async function addSubject(event) {
    event.preventDefault();

    try {
        const data = await api("/api/subjects", {
            method: "POST",
            body: JSON.stringify({
                name: document.getElementById("subjectName").value.trim(),
                exam_date: document.getElementById("examDate").value,
                difficulty: document.getElementById("difficulty").value,
                progress: Number(document.getElementById("progress").value),
                test_score: Number(document.getElementById("testScore").value),
                study_hours: Number(document.getElementById("totalStudyHours").value)
            })
        });

        showToast(data.message);
        document.getElementById("subjectForm").reset();
        document.getElementById("difficulty").value = "Medium";
        document.getElementById("progress").value = 0;
        document.getElementById("testScore").value = 0;
        document.getElementById("totalStudyHours").value = 5;

        await loadDashboard();
        await loadPlan();
    } catch (error) {
        showToast(error.message, "error");
    }
}

async function deleteSubject(id) {
    if (!confirm("Delete this subject and its recorded sessions?")) return;

    try {
        const data = await api(`/api/subjects/${id}`, {method: "DELETE"});
        showToast(data.message);
        await loadDashboard();
        await loadPlan();
    } catch (error) {
        showToast(error.message, "error");
    }
}

async function saveAvailability(event) {
    event.preventDefault();

    const days = [...document.querySelectorAll('input[name="studyDay"]:checked')]
        .map(input => input.value);

    try {
        const data = await api("/api/availability", {
            method: "POST",
            body: JSON.stringify({
                days,
                start_time: document.getElementById("startTime").value,
                end_time: document.getElementById("endTime").value,
                daily_hours: Number(document.getElementById("dailyHours").value)
            })
        });

        showToast(data.message);
        await loadPlan();
    } catch (error) {
        showToast(error.message, "error");
    }
}

function restoreAvailability(availability) {
    if (!availability) return;

    document.querySelectorAll('input[name="studyDay"]').forEach(input => {
        input.checked = availability.days.includes(input.value);
    });

    document.getElementById("startTime").value = availability.start_time || "18:00";
    document.getElementById("endTime").value = availability.end_time || "21:00";
    document.getElementById("dailyHours").value = availability.daily_hours || 3;
}

async function loadPlan() {
    try {
        const data = await api("/api/plan");
        renderPlan(data.plan);
    } catch (error) {
        console.error(error);
    }
}

function renderPlan(plan) {
    const container = document.getElementById("weeklyPlan");

    if (!plan.length) {
        container.innerHTML = `<div class="empty-state"><p>Add subjects to generate a plan.</p></div>`;
        return;
    }

    const hasSessions = plan.some(day => day.sessions.length);

    if (!hasSessions) {
        container.innerHTML = `<div class="empty-state"><p>No study days are selected. Choose availability above.</p></div>`;
        return;
    }

    container.innerHTML = plan.map(day => `
        <div class="plan-day">
            <div class="plan-day-header">
                <h3>${day.day}</h3>
                <span>${formatDate(day.date)}</span>
            </div>
            ${
                day.sessions.length
                ? day.sessions.map(session => `
                    <div class="study-session">
                        <div class="session-info">
                            <strong>${session.start} – ${session.end}</strong>
                            <span>${escapeHTML(session.subject)}</span>
                            <small>${session.hours}h · ${escapeHTML(session.topic)}</small>
                        </div>
                        <button onclick="recordSession(${session.subject_id}, '${escapeJS(session.subject)}', ${session.hours})">
                            Mark Done
                        </button>
                    </div>
                `).join("")
                : `<p class="no-session">No study session scheduled.</p>`
            }
        </div>
    `).join("");
}

async function recordSession(subjectId, subjectName, duration) {
    try {
        const data = await api("/api/sessions", {
            method: "POST",
            body: JSON.stringify({
                subject_id: subjectId,
                duration,
                date: new Date().toISOString().slice(0, 10)
            })
        });

        showToast(`${subjectName}: ${data.message}`);
        await loadDashboard();
        await loadPlan();
    } catch (error) {
        showToast(error.message, "error");
    }
}

async function sendQuestion() {
    const input = document.getElementById("questionInput");
    const question = input.value.trim();

    if (!question) return;

    addMessage(question, "user");
    input.value = "";
    addMessage("Thinking...", "ai", true);

    try {
        const data = await api("/api/ask", {
            method: "POST",
            body: JSON.stringify({question})
        });

        removeThinking();
        addMessage(data.answer, "ai");
    } catch (error) {
        removeThinking();
        addMessage(`Sorry, something went wrong: ${error.message}`, "ai");
    }
}

function askQuestion(question) {
    document.getElementById("questionInput").value = question;
    sendQuestion();
}

function addMessage(text, type, thinking = false) {
    const messages = document.getElementById("chatMessages");
    const message = document.createElement("div");
    message.className = `message ${type}${thinking ? " thinking" : ""}`;

    const title = type === "user" ? "👤 You" : "🤖 AI Assistant";
    message.innerHTML = `<strong>${title}</strong><p>${formatText(text)}</p>`;

    messages.appendChild(message);
    messages.scrollTop = messages.scrollHeight;
}

function removeThinking() {
    const thinking = document.querySelector(".message.thinking");
    if (thinking) thinking.remove();
}

function handleEnter(event) {
    if (event.key === "Enter") sendQuestion();
}

function startPlanner() {
    document.getElementById("subjects").scrollIntoView({behavior: "smooth"});
}

function showFeatures() {
    document.getElementById("features").scrollIntoView({behavior: "smooth"});
}

function formatDate(value) {
    if (!value) return "N/A";
    const date = new Date(`${value}T00:00:00`);
    return date.toLocaleDateString(undefined, {
        day: "numeric",
        month: "short",
        year: "numeric"
    });
}

function formatText(text) {
    return escapeHTML(String(text)).replace(/\n/g, "<br>");
}

function escapeHTML(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function escapeJS(value) {
    return String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
}

function showToast(message, type = "success") {
    const old = document.querySelector(".smartstudy-message");
    if (old) old.remove();

    const toast = document.createElement("div");
    toast.className = `smartstudy-message ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => toast.remove(), 3500);
}

function setupTheme() {
    const button = document.getElementById("themeToggle");
    const saved = localStorage.getItem("smartstudy-theme");

    if (saved === "light") {
        document.body.classList.add("light-theme");
        button.textContent = "☀️";
    }

    button.addEventListener("click", () => {
        document.body.classList.toggle("light-theme");
        const light = document.body.classList.contains("light-theme");
        button.textContent = light ? "☀️" : "🌙";
        localStorage.setItem("smartstudy-theme", light ? "light" : "dark");
    });
}
